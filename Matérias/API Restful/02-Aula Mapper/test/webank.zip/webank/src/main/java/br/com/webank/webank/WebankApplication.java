package br.com.webank.webank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebankApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebankApplication.class, args);
	}

}
